package Utility;

public class Constant {
	  public static final String URL = "http://newtours.demoaut.com/";
	  
      public static final String Username = "testuser_1";
 
      public static final String Password = "Test@123";
 
      public static final String Path_TestData = "C:\\work\\Basic_Selenium\\DDF\\src\\testdata";
 
      public static final String File_TestData = "testdata.xlsx";
}
